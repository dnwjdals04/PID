import os
import cv2
import numpy as np
import logging
from ultralytics import YOLO
from app.services.state import PROCESS_STATUS, PROCESS_LOCK

# ======== 기본 설정 ========
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

_model = None  # Lazy Load용 전역 모델

# ======== Lazy Load ========
def get_model():
    """프로세스별로 YOLO 모델을 로드 (병렬 안전)"""
    global _model
    if _model is None:
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        MODEL_PATH = os.path.join(BASE_DIR, "models", "yolov8s-seg.pt")
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(f"모델 파일이 없습니다: {MODEL_PATH}")
        _model = YOLO(MODEL_PATH, task="segment")
        logger.info(f"✅ YOLO 모델 로드됨 (프로세스 PID={os.getpid()})")
    return _model


# ======== 블러 처리 ========
def mask_blur(image_path_or_np_array, blur_strength=25, target_classes=[0, 2, 3, 5, 7]):
    model = get_model()

    if isinstance(image_path_or_np_array, str):
        img = cv2.imread(image_path_or_np_array)
        if img is None:
            logger.error(f"이미지를 읽을 수 없습니다: {image_path_or_np_array}")
            return None
    else:
        img = image_path_or_np_array

    if blur_strength % 2 == 0:
        blur_strength += 1

    results = model(img, verbose=False)[0]
    if results.masks is None:
        return img  # 탐지 없음 → 원본 반환

    processed_img = img.copy()
    for i, mask in enumerate(results.masks.data):
        cls_id = int(results.boxes.cls[i].cpu().numpy())
        conf = float(results.boxes.conf[i].cpu().numpy())

        if cls_id not in target_classes or conf < 0.3:
            continue

        m = mask.cpu().numpy().astype(np.uint8) * 255
        m = cv2.resize(m, (img.shape[1], img.shape[0]))
        blurred = cv2.GaussianBlur(img, (blur_strength, blur_strength), 0)
        processed_img = np.where(m[:, :, None] == 255, blurred, processed_img)

        class_name = model.names[cls_id]
        logger.info(f"마스킹 적용: {class_name} (신뢰도 {conf:.2f})")

    return processed_img


# ======== 분석 (청크 단위) ========
def analyze(frame_files, file_id, chunk_idx=None, total_chunks=None):
    """
    프레임 리스트를 받아 마스킹 적용 후 results/{file_id}_{chunk_idx}/ 에 저장.
    SSE 진행률도 반영됨.
    """
    total_frames = len(frame_files)
    result_dir = os.path.join("./results", f"{file_id}_{chunk_idx}")
    os.makedirs(result_dir, exist_ok=True)

    processed_images = []
    total_detections = 0

    for i, frame_path in enumerate(frame_files):
        if not os.path.exists(frame_path):
            continue

        processed_img = mask_blur(frame_path)
        if processed_img is None:
            continue

        output_path = os.path.join(result_dir, f"processed_frame_{i:04d}.jpg")
        cv2.imwrite(output_path, processed_img)
        processed_images.append(output_path)
        total_detections += 1

        # 진행률 업데이트
        if file_id in PROCESS_STATUS and chunk_idx is not None and total_chunks is not None:
            local_progress = ((i + 1) / total_frames) * 100
            with PROCESS_LOCK:
                PROCESS_STATUS[file_id]["chunks"][chunk_idx] = local_progress
                avg_progress = sum(PROCESS_STATUS[file_id]["chunks"]) / total_chunks
                PROCESS_STATUS[file_id]["progress"] = round(10 + avg_progress * 0.85, 2)
                PROCESS_STATUS[file_id]["stage"] = (
                    f"청크 {chunk_idx + 1}/{total_chunks} ({local_progress:.1f}%) 처리 중"
                )
                logger.info(f"[진행률 갱신] {file_id}: {PROCESS_STATUS[file_id]['progress']}%")

    logger.info(f"[✅ 완료] file_id={file_id}, chunk={chunk_idx}, {total_detections}프레임 처리 완료.")
    return {"status": "success", "images": processed_images, "total_detections": total_detections}
