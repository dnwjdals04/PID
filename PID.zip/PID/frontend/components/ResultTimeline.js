export default function ResultTimeline({ detections }) {
  return (
    <div className="timeline-box">
      <h3>탐지 리포트</h3>
      <div className="timeline-bar">
        {detections.map((d, i) => (
          <div
            key={i}
            className={`timeline-segment ${
              d.type === "face" ? "yellow" : "red"
            }`}
            style={{
              left: `${d.start}%`,
              width: `${d.duration || 2}%`,
            }}
          />
        ))}
      </div>
      <ul>
        {detections.map((d, i) => (
          <li key={i}>
            [{d.type}] {d.count}건 감지 (시작: {d.start}s)
          </li>
        ))}
      </ul>
    </div>
  );
}
