"use client";
import { useRef } from "react";

export default function VideoCompareCard({ original, masked }) {
  const leftRef = useRef(null);
  const rightRef = useRef(null);

  const sync = (action) => {
    if (action === "play") {
      leftRef.current?.play();
      rightRef.current?.play();
    } else {
      leftRef.current?.pause();
      rightRef.current?.pause();
    }
  };

  return (
    <div className="compare-container">
      <div className="video-box">
        <video ref={leftRef} src={original} controls />
      </div>
      <div className="video-box">
        <video ref={rightRef} src={masked} controls />
      </div>
      <div className="button-row">
        <button onClick={() => sync("play")} className="button-green">
          재생
        </button>
        <button onClick={() => sync("pause")} className="button-red">
          일시정지
        </button>
      </div>
    </div>
  );
}
